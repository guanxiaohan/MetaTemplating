from .Template import Template

__version__ = "1.0.0"
__author__ = "guanxiaohan"
__license__ = "MIT"

__all__ = ["Template"]